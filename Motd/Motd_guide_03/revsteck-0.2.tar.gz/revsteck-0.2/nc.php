#!/usr/local/bin/php
<?php
/*  ____________________________________________________________________
   | RevSteckList - Simulador de netcat (nc -l -p -s)                   |
   | Copyright (C) 2004 tDs - tds@motdlabs.org   motdlabs.org           |
   |....................................................................|
   | vars_ini = rst_                                                    |
   | func_ini = RST_                                                    |
   |....................................................................|
   | Este programa � software livre; voc� pode redistribu�-lo e/ou      |
   | modific�-lo sob os termos da Licen�a P�blica Geral GNU, conforme   |
   | publicada pela Free Software Foundation; tanto a vers�o 2 da       |
   | Licen�a como (a seu crit�rio) qualquer vers�o mais nova.           |
   +====================================================================+
*/
define ('_REVSTECKLIST_VERSION_','0.2');

function RSL_uso () {
    $rsl_ver = _REVSTECKLIST_VERSION_;
    global $argv;
    echo 
          "\033[2J\033[0;0H\033[1m".
          str_repeat("-",60).
          "\n\rREVSTECKLIST $rsl_ver - by tDs - \033[4;1;43mMotdLabs.org".
          "\033[0m\n\r".
          " Uso:\n\r ".
          $argv[0].
          " <endereco ip><porta>\n\r".
          " <endereco ip> Endereco ip que ira receber a conexao.\n\r".
          " <porta>       Porta que recebera a conexao.\n\r".
          "\033[1m".
          str_repeat("-",60).
          "\033[0m\n\r";
}

if ($argc != 3) {
    RSL_uso ();
} else {
    $rsl_ip    = $argv[1];
    $rsl_porta = $argv[2];
    $rsl_socket = stream_socket_server("tcp://$rsl_ip:$rsl_porta", 
                                        $rsl_errno, $rsl_errstr);
    if (!$rsl_socket) {
        echo $rsl_errstr.' ('.$rsl_errno.")<br />\n";
    } else {
        $rsl_conn = stream_socket_accept($rsl_socket);
        $rsl_flag = 1;
        while ($rsl_flag) {
            while (  ($rsl_le = fgetc ($rsl_conn) ) != "\00" ) {
                echo $rsl_le;
            }
            $rsl_ler = fgets (STDIN,1024);
            stream_socket_sendto ($rsl_conn, $rsl_ler);
            if ( trim ($rsl_ler) == 'exit' )
                $rsl_flag = 0;
        }
    }
fclose($rsl_socket);
}

?>
