#!/usr/local/bin/php
<?php
/*  ____________________________________________________________________
   | Steck_telnet - Simulador de telnet em php                          |
   | Copyright (C) 2004 tDs - tds@motdlabs.org   motdlabs.org           |
   |....................................................................|
   | vars_ini = stc                                                     |
   | func_ini = STC                                                     |
   |....................................................................|
   | Este programa � software livre; voc� pode redistribu�-lo e/ou      |
   | modific�-lo sob os termos da Licen�a P�blica Geral GNU, conforme   |
   | publicada pela Free Software Foundation; tanto a vers�o 2 da       |
   | Licen�a como (a seu crit�rio) qualquer vers�o mais nova.           |
   +====================================================================+
*/
define ('_STECK_SECURE_', false);
define ('_STECKTELNET_VERSION_', '0.3');

/*** exibe informacoes sobre como usar */
function STC_uso () {
    global $argv;
    $stc_ver = _STECKTELNET_VERSION_;
    echo 
          "\033[2J\033[0;0H\033[1m".
          str_repeat("-",60).
          "\n\rSTECKTELNET $stc_ver - by tDs - \033[4;1;43mMotdLabs.org".
          "\033[0m\n\r".
          " Uso:\n\r ".
          $argv[0].
          " <endereco ip> <porta>\n\r".
          " <endereco ip> Endereco ip para conexao.\n\r".
          " <porta>       Porta para conexao.\n\r".
          "\033[1m".
          str_repeat("-",60).
          "\033[0m\n\r";
}

/*** fputs modificado. codifica dados, se necessario */
function STC_fputs ($stc_fd, $stc_cont, $stc_len) {
    if (_STECK_SECURE_ == true) {
        $stc_cont = base64_encode ($stc_cont);
        $stc_send = fputs ($stc_fd, $stc_cont, $stc_len);
        return ($stc_send);
    } else {
        $stc_send = fputs ($stc_fd, $stc_cont, $stc_len);
        return ($stc_send);
    }
}
    
/*** fgetc modificado. decodifica dados, se necessario */
function STC_fgetc ($stc_fd) {
    if (_STECK_SECURE_ == true) {
        $stc_get = fgetc ($stc_fd);
        $stc_get = base64_decode ($stc_get);
        return ($stc_get);
    } else {
        $stc_get = fgetc ($stc_fd);
        return ($stc_get);
    }
}

/*** fgets modificado. decodifica dados, se necessario */
function STC_fgets ($stc_fd, $stc_len) {
    if (_STECK_SECURE_ == true) {
        $stc_get = fgets ($stc_fd, $stc_len);
        $stc_get = base64_decode ($stc_get);
        return ($stc_get);
    } else {
        $stc_get = fgets ($stc_fd, $stc_len);
        return ($stc_get);
    }
}

/*** chamou com todos os argumentos? */
if ($argc != 3) {
    STC_uso ();
    exit (0);
}
    
$stc_ip    = $argv[1];
$stc_porta = $argv[2];

/*** abre conexao para o endereco especificado na porta especificada */
$stc_conexao = fsockopen ($stc_ip, $stc_porta, $stc_errno, $stc_errstr);
if (!$stc_conexao) {
    echo $stc_errstr.' ('.$stc_errno.")\n";
    exit (0);
}

$stc_flag = 1;
while ($stc_flag) {
    while (($stc_char = STC_fgetc($stc_conexao)) != "\00") {
        echo $stc_char;
    }
    $stc_escrever = STC_fgets (STDIN, 1024);
    STC_fputs ($stc_conexao, $stc_escrever, strlen ($stc_escrever));
    if ( (trim ($stc_escrever) == "T" || trim ($stc_escrever) == "exit") ) 
        break;
    continue;
}
?>