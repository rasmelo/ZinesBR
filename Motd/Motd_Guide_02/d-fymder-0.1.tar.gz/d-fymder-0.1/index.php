<?php
//                                                      ________
//                                                     |D-FYMDER|  
// +------------------------------------------------------------+
// + Arquivo principal - by tDs - tds@motdlabs.org              +
// +------------------------------------------------------------+
// + file: index.php                                            +
// +------------------------------------------------------------+
// + Arquivo interface do usuario e comunicador entre master e  +
// + slave                                                      +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+
//

/* ******************************************************************** 
 * CONFIGURACOES
 * configuracoes gerais
 */
//error_reporting(E_ALL ^ E_NOTICE);
error_reporting(0);
set_time_limit(10);
require_once "inc/cfg.inc.php";
require_once "inc/funcoes.inc.php";
/* ******************************************************************** 
 * INICIO_PAGINA
 * Parte incial da pagina e' criada por esta chamada.
 */

inicioPagina();                

echo '
<table align="center" class=tabelacentral>
    <tr>
        <td align="center">
        <table width="600" >
            <tr>
                <td>
                
                <font class=texto>
        ';
/* ******************************************************************** 
 * PASSO_UM
 * Se estiver abrindo pela primeira vez, exibe o primeiro formulario 
 * para scannear. Nenhuma outra funcao e' executada, indo direto para
 * FINAL_PAGINA
 */
    if (!$scanear || $scanear == "INICIO")
    {
        formulario_scanP1();
        $ajuda = 1; 
    }
/* ******************************************************************** 
 * PASSO_DOIS
 * Se tiver clicado no botao "Adicionar Slaves", que aparece no 
 * PASSO_UM, ira executar este if, caso todos os campos do formulario
 * anterior foram peenchidos corretamente. Apos isso, vai para o 
 * FINAL_PAGINA
 */
if ($scanear == "Adicionar Slaves")
{
    echo "";
    $flag = 0;
    unset($erro);
    if (!$master)
    {
        $erro .= msg_esp_master.".<br>";
        $flag = 1;
    }
    if (!$host)
    {   
        $erro .= msg_esp_vitima."<br>";
        $flag = 1;
    }
    if (!$portaSeguidas && !$portaVariadas)
    {
        $erro .= msg_sel_portas."<br>";
        $flag = 1;
    }
    if ($portaSeguidas && $portaVariadas)
    {
        $erro .= msg_por_umform."<br>";
        $flag = 1;
    }
    if ($slaves < 1)
    {
        $erro .= msg_esp_slaves."<br>";
        $flag = 1;
    }
    if ($timeout < 1)
    {   
        $erro .= msg_timeout_bx."<br>";
        $flag = 1;
    }
    if ($master && !is_master($master))
    {
        $erro = msg_master_inv."<br>";
        $flag = 1;
    }
    if ($flag == 1)
    {
        echo "<center>".
             "<input type=button name=voltar value=Voltar ".
             "onclick=\"history.back(-1)\" accesskey=V>".
             "<hr></center>\r".

             "$erro<br><font class=alerta>".msg_corr_erros."</font>";
        $ajuda = "ERRO";
    }
    if ($ajuda != "ERRO")
    {
        echo "<center>".
         "<form name=formul action=index.php method=post>\r".
         "<input type=submit name=scanear value=OK accesskey=O> \r".
         "<input type=reset name=limpar value=Limpar accesskey=L> ".
         "<input type=button name=voltar value=Voltar ".
         "onclick=\"history.back(-1)\" accesskey=V>".
         "<hr></center>\r".
         "<input type=hidden name=master value=$master>\r".
         "<input type=hidden name=host  value=$host>\r".
         "<input type=hidden name=portaSeguidas value=$portaSeguidas>\r".
         "<input type=hidden name=portaVariadas value=$portaVariadas>\r".
         "<input type=hidden name=timeout value=$timeout>";
        for ($contador = 0;$contador < $slaves;$contador++)
        {
            if ($contador == _MAX_SLAVES_){$contador = $slaves;}
            echo "<input type=text name='slave[".$contador."]' size=50><br>\r".
                 msg_slave."$contador:<br><br>";
        }
        "</form>";
        $ajuda = 2;
    }
}
/* ******************************************************************** 
 * PASSO_TRES
 * Se tiver clicado no botao "OK", que aparece no 
 * PASSO_DOIS, ira executar este if. 
 * Caso todos os slaves sejam mesmo slaves, executa o 
 * PASSO_QUATRO, caso contrario, informa o erro e vai para o 
 * FINAL_PAGINA
 */
if ($scanear == "OK")
{
    $slaves = sizeof($slave);
    for ($contador = 0; $contador < $slaves;$contador++)
    {
        if (!is_slave($slave[$contador]))
        {
            $msg .=  msg_o_slave." $contador ".msg_n_valido."<br>";
            
            $ajuda = "ERRO";
        }
    }
    if ($ajuda == "ERRO")
    {
        echo "<center>".
        "<form action=index.php method=post>\r".
        "<input type=button name=voltar value=Voltar ".
        "onclick=\"history.back(-1)\" accesskey=V></form>".
        "<hr></center>\r".
        "$msg<br><font class=alerta>".msg_corr_erros."</font>";
        unset ($scanear);
    }
        
}
/* ******************************************************************** 
 * PASSO_QUATRO
 * Exibe as informacoes do scan e prepara as portas. Apos isso vai para
 * FINAL_PAGINA
 * Dependendo da  quantidade de portas o conteudo da pagina ficara 
 * enorme, de input hidden. Apos verificacao das informacoes, o usuario 
 * pode clicar em "Manda Ver", que ira executar o ULTIMO_PASSO
 */
if ($scanear == "OK")
{
    $slaves = sizeof($slave);
    
    if($portaSeguidas){$portas = prepara_portas($portaSeguidas);}
    if($portaVariadas){$portas = prepara_portas($portaVariadas);}
    echo "<center><form action=index.php method=post>\r";
    if ($portas != "ERRO")
    {
        echo "<input type=submit name=scanear ".
             "value='Manda Ver' accesskey=M> \r";
    }
    echo "<input type=button name=voltar value=Voltar ".
         "onclick=\"history.back(-1)\" accesskey=V>".
       "<hr></center>\r".
       "<input type=hidden name=master value=$master>\r".
       "<input type=hidden name=host  value=$host>\r".
       "<input type=hidden name=portaSeguidas value=$portaSeguidas>\r".
       "<input type=hidden name=portaVariadas value=$portaVariadas>\r".
       "<input type=hidden name=timeout value=$timeout>\r";
    for ($contador = 0;$contador < $slaves;$contador++)
    {
        echo 
            "<input type=hidden name=slave[".$contador."] value=".
            $slave[$contador].">\r";
    }
    
    if ($portas == "ERRO")
    {
        echo msg_portas_inv."<br><br>".
             "<font class=alerta>".msg_corr_erros."</font>";
        $erro = 1;
        $ajuda = "ERRO";
        
    }
    if (!$erro)
    {
        for ($contador = 0; $contador < sizeof($portas); $contador++)
        {
            echo "<input type=hidden name=portas[$contador] value=".
            $portas[$contador].">\r";
        }
    
        $qPortas = sizeof($portas);
        $x = $qPortas - 1;
        $ultPorta = $portas[$x];
        echo    msg_slave2.sizeof($slave)."<br>".
                msg_vitima2."$host<br>\r".
                msg_porta_ini.$portas[0]."<br>\r".
                msg_porta_fin.$ultPorta."<br>\r".
                msg_timeout.$timeout."<br>\r";
        echo "</form>";
        $ajuda = 3;
    }
}

/* ******************************************************************** 
 * ULTIMO_PASSO
 * Aqui o scanneamento sera feito.
 * exibicao do resultado e futuras implementacoes de verificacao de 
 * assinaturas de daemons serao feitas aqui. Acredito ser a parte
 * mais sensivel do script, mesmo sendo muito simples o funcionamento.
 * apos o scan, vai para
 * FINAL_PAGINA
 */
if($scanear == "Manda Ver")
{
    $master = _REPLY_ADD_;
    $qPortas = sizeof($portas);
    $timeout = $timeout;
    $qSlaves = sizeof($slave);
    $inicio_ed = getmicrotime();
    preparaArqResult();
    echo msg_scanning."$host... <br><br><br>";
    for ($contPorta = 0; $contPorta < $qPortas;)
    {
        for ($contSlave = 0;$contSlave < $qSlaves;$contSlave++)
        {
            if($contPorta == $qPortas){break;}
            $link = $slave[$contSlave]."?Scan=Scan&master=$master&host=";
            $link .= "$host&porta=".$portas[$contPorta]."&timeout=$timeout";
            //echo $link."<br>";
            $envia = fopen($link,"r");
            
            $a = fread($envia,1000);
            fclose($envia);
            //echo $a."<br>";
            unset($envia);
            $flag = 1;
            $contPorta++;
        }
    }
            
    echo "<center>".msg_result_scan."<br>";
    $fim_sc = round(getmicrotime() - $inicio_ed,2);
    $a = fopen(_ARQ_REPLY_,"r");
    $b = fread ($a,filesize(_ARQ_REPLY_));
    
    echo "<table>";
    echo "<tr class=tpscan><td>".msg_porta."</td><td>".msg_status."</td>".
         "<td>".msg_servico."</td></tr>";
    echo nl2br($b);
    echo "</table>";
    
    echo msg_tempo_scan."$fim_sc s";
    echo "<hr><center>".
         "<form name=formul action=index.php method=post>\r".
         "<input type=submit name=scanear value=INICIO accesskey=O>".
         "</center>\r";
    $ajuda = 4;
}
/* ******************************************************************** 
 * FINAL_PAGINA
 * fecha tabelas, exibe rodape, boneco de ajuda, etc...
 */
echo "                  </font>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>";

/* -------------------------------------------------------- */
echo '
                </td>
                <td class=tdireita>&nbsp;</td>
            </tr>
            <tr>
                
                <td width="100" class=tprincipal colspan="2" align="center">
                    <center>';

boneco_ajuda($ajuda);
finalPagina();
?>
