<?php
//                                                      ________
//                                                     |D-FYMDER|  
// +------------------------------------------------------------+
// + Slave - by tDs - tds@motdlabs.org                          +
// +------------------------------------------------------------+
// + file: slave.php                                            +
// +------------------------------------------------------------+
// + Arquivo escravo.                                           +
// + O script recebe 4 variaveis:                               +
// + $host = ip da vitima                                       +
// + $porta = porta que deve ser scaneada                       +
// + $timeout = tempo maximo para tentar conexao na porta X     +
// + $master = o endereco que recebera a resposta               +
// +                                                            +  
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+
//

require_once ("inc/cfg.inc.php");
require_once ("inc/slave.funcoes.inc.php");
//error_reporting(E_ALL ^ E_NOTICE);
error_reporting(0);

if ($is_slave == 1)
{
    simeusou();
    exit();
}

/**
 * exibe o formulario para entrada de informacoes.
 */

if (!$Scan)
{
    //formulario_scan();
    return(0);
}
/**
 * prepara dados sobre o scan
 */
$ipVitima = $host;
$poVitima = intval($porta);
$timeout = intval($timeout);
$ipMaster = $master;
/**
 * aqui ocorre o scan...
 * se a porta esta aberta retorna 0, caso contrario retorna:
 * $scVitima[0] = 1
 * $scVitima[1] = codigo do erro
 * $scVitima[2] = descricao do erro
 */
//sleep(1);
$scVitima = portaStatus($ipVitima,$poVitima,$timeout);

/**
 * prepara resposta
 */
$link = $ipMaster;     // obtem url que deve recebera resposta do scan
$link .= "?r1=";        // append resposta 1
$link .= $scVitima[0]; // ao endereco que recebera a resposta (url)
$link .= "&r4=";        // append resposta 4
$link .= $poVitima;    // a porta da vitima 
$link .= "&r2=";        // append resposta 2
$link .= $scVitima[1]; // ao endereco que recebera a resposta (url)
$link .= "&r3=";        // ta na cara 
$link .= $scVitima[2]; // o que e' esta linha

$ipVitima = $ipVitima;

/**
 * se a porta esta aberta...
 */
if ($scVitima == 0)
{
    $enviaResposta = fopen($link,"r");
    echo msg_aporta." $poVitima ".msg_dohost." $ipVitima ".msg_aberta;
    echo "<br>$link;";
    exit(0);
}

/**
 * se chegou aqui e' porque a porta esta fechada. informe...
 */
echo msg_aporta." $poVitima ".msg_dohost." $ipVitima ".msg_fechada."<br>".
      $scVitima[2] ." - Codigo ".$scVitima[1];

/**
 * envia resposta ao master
 */
$enviaResposta = fopen($link,"r");
    echo "<br>$link";

?>
