<?php
//                                                      ________
//                                                     |D-FYMDER|  
// +------------------------------------------------------------+
// + Master - by tDs - tds@motdlabs.org                         +
// +------------------------------------------------------------+
// + file: rc_reply.php                                         +
// +------------------------------------------------------------+
// + Arquivo master.                                            +
// + O script recebe 4 variaveis:                               +
// + $r1 = 1 se porta estava fechada                            +
// + $r2 = codigo do erro                                       +
// + $r3 = descricao do erro                                    +
// + $r4 = numero da porta                                      +
// +                                                            +  
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+
//
//error_reporting(E_ALL ^ E_NOTICE);
error_reporting(0);
require_once ("inc/cfg.inc.php");
/**
 *
 * apos tratamento das variaveis de entrada, 
 * escreve para _ARQ_REPLY_ a resposta do scan, no formato
 * porta;status;servico; onde
 * porta = numero da porta
 * status = 0 se porta aberta , status = 1 se porta fechada
 * servico = getservicebyname()
 */
function retServico ($porta, $proto = "tcp")
{
    $servico = getservbyport($porta,$proto);
    return ($servico);
}

if ($is_master == 1)
{
    echo _MASTER_ASS_;
    exit(0);
}
$erCodigo = $r2;
$erDescricao = $r3;
$poNumero = $r4;
$poStatus = "fechada";

$servico = retServico($poNumero);


if($r1 == 0){    $poStatus = "aberta";}
if(!$r2){    $erCodigo = "0";}
if(!$r3){    $erDescricao = "0";}    
if(!$r4){    $poNumero = "0";}
if(!$servico){    $servico = "desconhecido";}

$flag = 0;
if ($poStatus == "aberta")
{
    $resposta = "<tr class=tpaberta>".
                    "<td>$poNumero</td>".
                    "<td>$poStatus</td>".
                    //"<td>$erCodigo</td>".
                   "<td>$servico</td>".
               "</tr>";
   $flag = 1;

}



if (_MOSTRAR_PORTA_FECHADA_ == "1" && $flag == 0)
{
    $resposta = "<tr class=tpfechada>".
                    "<td>$poNumero</td>".
                    "<td>$poStatus</td>".
                    //"<td>$erCodigo</td>".
                   "<td>$servico</td>".
               "</tr>";
}

$crArquivo = fopen(_ARQ_REPLY_,"a+");
$esArquivo = fwrite($crArquivo,$resposta);
$feArquivo = fclose($crArquivo);

?>
