O QUE E':
Um scanner de rede (em breve de vulnerabilidades) distribuido 
em desenvolvido em php (www.php.net)

COMO FUNCIONA:
O scanner funciona basicamente com tres scripts:
- interface
- master
- slave
Os dados do scan sao informados na interface do scanner. A interface
por sua vez, repassa os dados aos slaves. Os slaves, em posse dos dados,
efetuam entao o scanneamento. Apos isso, eles informam ao master o resultado
do scan. O master repassa entao a informacao ao usuario, atraves da interface.


TECNICAS DE SCAN:
Atualmente o D-FYMDER faz scanneamento utilizando a funcao fsockopen(), ou seja, 
nao utiliza nenhuma tecnica de evasao, sendo assim facilmente detectado se a proporcao
slave/portas for alta (Exemplo: 2 slaves e 20 portas. Cada slave verificaria 10 portas 
no host).

REQUERIMENTOS:
- Servidor web que suporte PHP
- Versao recente de PHP
- Arquivo temp/result.txt deve ter direito de escrita.

ONDE BAIXAR:
http://dfymder.motdlabs.org/dfhp/index.php?id=downloads

