<?php
//                                                      ________
//                                                     |D-FYMDER|  
// +------------------------------------------------------------+
// + Configuracoes gerais - by tDs - tds@motdlabs.org           +
// +------------------------------------------------------------+
// + file: cfg.inc.php                                          +
// +------------------------------------------------------------+
// + Arquivo com configuracoes gerais                           +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+
//
//require_once "inc/en.lang.php";
require_once "inc/pt_br.lang.php";

$ip = $_SERVER['REMOTE_ADDR'];
define ("_SERVER_BASE_","http://127.0.0.1:10000/d-fymder/");
define ("_REPLY_ADD_","http://127.0.0.1:10000/d-fymder/rc_reply.php");
define ("_ARQ_REPLY_","temp/result.txt");
define ("_MAX_SLAVES_","30");
define ("_PORTAS_PADRAO_ALT_","21,22,23,25,53,80,110");
define ("_PORTAS_PADRAO_SEG_","1-80");
define ("_VITIMA_","127.0.0.1");
define ("_SLAVE_EX_","http://127.0.0.1:10000/d-fymder/slave.php");
define ("_SLAVE_ASS_","yes, i am!");                       
define ("_MASTER_ASS_","yes, i am!");                       
define ("_TITULO_",msg_titulo);
define ("_RODAPE_",msg_rodape);
define ("_MSG_MASTER_","<u>M</u>aster");
define ("_MSG_ABOUT_","D-FYMDER v0.1.\\n Acho que nem funciona ainda.\\n". 
                       "Qualquer duvida: tds@motdlabs.org.\\n by tDs");
define ("_MOSTRAR_PORTA_FECHADA_","1");
define ("_MAX_PORTAS_","20");

?>
