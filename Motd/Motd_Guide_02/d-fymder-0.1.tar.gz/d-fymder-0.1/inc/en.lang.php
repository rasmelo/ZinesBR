<?php
//                                                      ________
//                                                     |D-FYMDER|  
// +------------------------------------------------------------+
// + en Idioma - by tDs - tds@motdlabs.org                      +
// +------------------------------------------------------------+
// + file: inc/en.lang.php                                      +  
// +------------------------------------------------------------+
// + Arquivo com mensagens em ingles ATENCAO: AS MENSAGENS NAO  +
// + ESTAO TRADUZIDAS CORRETAMENTE! SE QUISER TRADUZIR CERTINHO +
// + SINTA-SE A VONTADE EM ENVIAR UMA COPIA PARA MIM!           +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+
//
define ("msg_aberta","is opened.");
define ("msg_adicionar_exe","Add a exemple.");
define ("msg_ajuda_erro","Ops...\\n There is a error here!");
define ("msg_ajuda_final","I hope help!\\nSee you later.");
define ("msg_ajuda_confirma","Confirm data and fire up!");
define ("msg_ajuda_end_slave","Put here the slaves address.");
define ("msg_aporta","The port ");

define("msg_corr_erros","Correct these errors to continue.");

define ("msg_dohost","of host ");

define("msg_esp_master","You must specify the <u>Master</u>'s address");
define("msg_esp_slaves","You must add one <u>Slave</u>.");
define("msg_esp_vitima","You must specify the <u>Target</u> of the scan.");

define ("msg_fechada","is closed.");

define ("msg_limpar","Reset.");

define ("msg_master","<u>M</u>aster:");
define("msg_master_inv","The <u>Master</u> is not valid!");

define("msg_n_valido","is not valid!");

define("msg_o_slave","The Slave");

define("msg_por_umform","You must choose only <u>one Port Format</u>.");
define("msg_porta","Port");
define("msg_porta_fin","Final Port -  ");
define("msg_porta_ini","Initial Port -  ");
define("msg_portas_inv","Invalid Ports Format or many ports.");
define("msg_portas_seguidas","<u>P</u>orts: (Format:1-80):");
define("msg_portas_variadas","P<u>o</u>rts: (Format:21,22,23,80):");

define("msg_result_scan","Scan result:");
define("msg_rodape","motdlabs.org - beta version, testing.<br>");

define("msg_scanning","Scanning ");
define("msg_sel_portas","You must specify <u>Ports</u> to be scanned.");
define("msg_servico","Service");
define("msg_slave","Slave ");
define("msg_slave2","Slaves - ");
define("msg_slaves","Sla<u>v</u>es:");
define("msg_status","Status");

define("msg_tempo_scan","Approach Time: ");
define("msg_timeout","Timeout connection - ");
define("msg_timeout_bx","The <u>Timeout</u> is not a bit low?");
define("msg_timeout_ini","T<u>i</u>meout:");
define("msg_titulo","D-FYMDER");

define("msg_vitima","<u>T</u>arget: ");
define("msg_vitima2","Target - ");
















define ("msg_ajuda_principal","Master: Address of the script that will receive the reply.\\n".
"The file that contain the script is rc_reply.php\\n\\n\\n\\n".
"Target: Address that will be scanned.\\n\\n\\n\\n".
"Ports: (Format:1-80): Range of ports. \\nObs.: Currently the ".
"script do not accepts a range very big.\\n".
"Ex: 1-80\\n\\n\\n\\n".
"Ports: (Format:21,22,23,80): Alone Ports to scan. \\nObs.:".
"Currently the script do not accept combination of alone and range".
" ports.\\n".
"Ex: 21,23,25,53,57,80,110.\\n\\n\\n\\n".
"Slaves: Address of script that will really work. ".
"The file that contain the o script is slave.php\\n\\n\\n\\n".
"Timeout: Max time for connect in each port.");



?>
