<?php
//                                                      ________
//                                                     |D-FYMDER|  
// +------------------------------------------------------------+
// + Funcoes para slaves - by tDs - tds@motdlabs.org            +
// +------------------------------------------------------------+
// + file: slave.funcoes.inc.php                                +
// +------------------------------------------------------------+
// + Arquivo com funcoes utilizadas por slaves.                 +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+
//

/**
 * FUNCAO PORTA STATUS
 *
 * Verificar o estado da porta $porta 
 * se a porta esta aberta retorna 0, caso contrario retorna um array:
 * $scVitima[0] = 1
 * $scVitima[1] = codigo do erro
 * $scVitima[2] = descricao do erro
 * 
 */
function portaStatus($host,$porta,$timeout)
{
    
    $sOpen = fsockopen($host, $porta, $cErro, $dErro,$timeout);
    
    if (!$sOpen) 
    {
        $erro[0] = 1;
        $erro[1] = $cErro;
        $erro[2] = $dErro;
        
        return ($erro);
    }
    return(0);
}

/**
 * FUNCAO FORMULARIO SCAN
 *
 * Exibe formulario para scan
 */
function formulario_scan()
{
    echo "
    <form action="._SERVER_BASE_."slave.php"." method=post>
    <input type=text name=host  value='127.0.0.1' size=30>
    <-- Host (IP)<br>
    <input type=text name=porta size=9 value=10000>
    <-- Porta 
    <input type=text name=timeout size=9>
    <-- Tempo limite de conexao (s) <br>
    <input type=text name=master size=30 value='".
    "http://127.0.0.1:10000/ld/rc_reply.php'> <-- Master <br>
    <input type=submit name=Scan value=Scan>
    </form>";
    return(0);
}

/**
 * FUNCAO IS SLAVE
 *
 * Responde ao Master que e' um slave, se questionado
 */
function simeusou()
{
    echo _SLAVE_ASS_;
    return(0);
}

?>
