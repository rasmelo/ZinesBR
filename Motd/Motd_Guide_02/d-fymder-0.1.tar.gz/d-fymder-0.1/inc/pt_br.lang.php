<?php
//                                                      ________
//                                                     |D-FYMDER|  
// +------------------------------------------------------------+
// + PT_BR Idioma - by tDs - tds@motdlabs.org                   +
// +------------------------------------------------------------+
// + file: inc/pt_br.lang.php                                   + 
// +------------------------------------------------------------+
// + Arquivo com mensagens em portugues do brasil (pt_br)       +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+
//
define ("msg_aberta","esta aberta.");
define ("msg_adicionar_exe","Adicione um exemplo.");
define ("msg_ajuda_erro","Ops...\\n Voce fez algo errado!");
define ("msg_ajuda_final","Espero que tenha lhe ajudado!\\nAte a proxima.");
define ("msg_ajuda_confirma","Verifique se os dados estao certos e mande ver!");
define ("msg_ajuda_end_slave","Coloque aqui o endereco dos slaves.");
define ("msg_aporta","A porta ");

define("msg_corr_erros","Corrija os erros acima para continuar.");

define("msg_dohost","do host ");

define("msg_esp_master","Voce deve especificar o endereco do <u>Master</u>");
define("msg_esp_slaves","Voce deve adicionar ao menos um <u>Slave</u>.");
define("msg_esp_vitima","Voce deve especificar a <u>Vitima</u> a ser scaneada.");

define("msg_fechada","esta fechada.");

define("msg_limpar","Limpar.");

define("msg_master","<u>M</u>aster:");
define("msg_master_inv","O <u>Master</u> nao e' valido!");

define("msg_n_valido","nao e' valido!");

define("msg_o_slave","O slave");

define("msg_por_umform","Voce deve selecionar apenas <u>um formato de Portas</u>.");
define("msg_porta","Porta");
define("msg_porta_fin","Porta final -  ");
define("msg_porta_ini","Porta inicial -  ");
define("msg_portas_inv","Formato de portas invalido ou muitas portas.");
define("msg_portas_seguidas","<u>P</u>ortas: (Formato:1-80):");
define("msg_portas_variadas","P<u>o</u>rtas: (Formato:21,22,23,80):");

define("msg_result_scan","Resultado do scan:");
define("msg_rodape","motdlabs.org - versao beta, em testes.<br>");

define("msg_scanning","Scaneando ");
define("msg_sel_portas","Voce deve selecionar <u>Portas</u> a serem scaneadas");
define("msg_servico","Servico");
define("msg_slave","Slave:");
define("msg_slave2","Slaves - ");
define("msg_slaves","Sla<u>v</u>es:");
define("msg_status","Status");

define("msg_tempo_scan","Tempo aprox.: ");
define("msg_timeout","Tempo de conexao - ");
define("msg_timeout_bx","O <u>Tempo limite</u> nao esta muito baixo?");
define("msg_timeout_ini","Tempo l<u>i</u>mite:");
define("msg_titulo","D-FYMDER");

define("msg_vitima","Vi<u>t</u>ima: ");
define("msg_vitima2","Vitima - ");









define ("msg_ajuda_principal","Master: Endereco do script que recebera a resposta.".
"O nome do arquivo que contem o script � rc_reply.php\\n\\n\\n\\n".
"Vitima: Endereco de quem sera escaneado.\\n\\n\\n\\n".
"Portas: (Formato:1-80): Range de portas. \\nObs.: Atualmente o ".
"script nao aceita uma range muito grande.\\n".
" Ex: 1-80\\n\\n\\n\\n".
"Portas: (Formato:21,22,23,80): Portas unicas a scanear. \\nObs.:".
"Atualmente o script nao aceita combinacao de portas unicas e range".
" de portas.\\n".
"Ex: 21,23,25,53,57,80,110.\\n\\n\\n\\n".
"Slaves: Endereco do script que fara a parte suja do trabalho. ".
"O nome do arquivo que contem o script � slave.php\\n\\n\\n\\n".
"Tempo limite: Tempo maximo para conexao em cada porta.");



?>
