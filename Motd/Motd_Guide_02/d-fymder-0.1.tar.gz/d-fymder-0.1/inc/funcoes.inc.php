<?php
//                                                      ________
//                                                     |D-FYMDER|  
// +------------------------------------------------------------+
// + Funcoes para slaves - by tDs - tds@motdlabs.org            +
// +------------------------------------------------------------+
// + file: funcoes.inc.php                                      +
// +------------------------------------------------------------+
// + Arquivo com funcoes utilizadas pelo master e para          +
// + comunicao com slaves (funcoes gerais)                      +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+
//

/***
 * FUNCAO PREPARACAO DE ARQUIVOS
 * 
 * Prepara arquivo(s) que serao utilizados durante o 
 * scaneamento. O Diretorio onde se encontra o arquivo  
 * deve ter permissao de escrita.
 */
function preparaArqResult()
{
    $arquivo = _ARQ_REPLY_;
    if (file_exists($arquivo))
    {
        unlink($arquivo);
    }
    touch($arquivo);
    return(0);
}
/***
 * FUNCAO FORMULARIO
 *
 * Exibe primeiro formulario para scan
 */
function formulario_scanP1()
{
    $exemplo = msg_adicionar_exe;
    $limpar  = msg_limpar;
    echo 
    '<center>'.
    '<form action=index.php method=post name="f">'.
    '<input type=submit name=scanear value="Adicionar Slaves" accesskey=A>'.
    ' <input type=reset name=limpar value=Limpar accesskey=L>'.
    '<hr></center>'.
    
    '<input type=text name=master size=50 accesskey=M>'.
    '<img  title="'.$exemplo.'" type=button src="img/preencher.gif"'.
    ' onclick="f.master.value=\''._REPLY_ADD_.'\'"> 
     <img  title="'.$limpar.'"  type=button src="img/limpar.gif"'.
    ' onclick="f.master.value=\'\'"><br>'.
    msg_master.'<br>'.
    
    '<input type=text name=host size=50 accesskey=T>'.
    '<img  title="'.$exemplo.'" type=button src="img/preencher.gif"'. 
    ' onclick="f.host.value=\''._VITIMA_.'\'"> 
     <img  title="'.$limpar.'"    type=button src="img/limpar.gif"'.    
    ' onclick="f.host.value=\'\'"><br>'.
    msg_vitima.'<br>'.
    
    '<input type=text name=portaSeguidas size=30 accesskey=P>'.
    '<img  title="'.$exemplo.'" type=button src="img/preencher.gif"'. 
    ' onclick="f.portaSeguidas.value=\''._PORTAS_PADRAO_SEG_.'\'"> 
     <img  title="'.$limpar.'"    type=button src="img/limpar.gif"'.    
     ' onclick="f.portaSeguidas.value=\'\'"><br>'.
    msg_portas_seguidas.'<br>'.
    
    
    '<input type=text name=portaVariadas size=30 accesskey=o>'.
    '<img  title="'.$exemplo.'" type=button src="img/preencher.gif"'. 
    ' onclick="f.portaVariadas.value=\''._PORTAS_PADRAO_ALT_.'\'"> 
     <img  title="'.$limpar.'"    type=button src="img/limpar.gif"'.    
     ' onclick="f.portaVariadas.value=\'\'"><br>'.
    msg_portas_variadas.'<br>'.
    
    '<input type=text name=slaves size=15 accesskey=v>'.
    '<img  title="'.$exemplo.'" type=button src="img/preencher.gif"'. 
    ' onclick="f.slaves.value=1"> 
     <img  title="'.$limpar.'"    type=button src="img/limpar.gif"'.    
     ' onclick="f.slaves.value=\'\'"><br>'.
    msg_slaves.'<br>'.
    
    '<input type=text name=timeout size=15 accesskey=I>'.
    '<img  title="'.$exemplo.'" type=button src="img/preencher.gif"'. 
    ' onclick="f.timeout.value=1"> 
     <img  title="'.$limpar.'"    type=button src="img/limpar.gif"'.    
     ' onclick="f.timeout.value=\'\'"><br>'.
    msg_timeout_ini.'<br>'.
    
    "</form>\r";
    return(0);
}

/***
 * FUNCAO PREPARA PORTAS
 *
 * prepara as portas para scaneamento. <br>
 * se recebe como argumento, por exemplo, "70-74", retorna um array da seguinte forma: <br>
 * $porta[0] = 70 <br>
 * $porta[1] = 71 <br>
 * $porta[2] = 72 <br>
 * $porta[3] = 73 <br>
 * $porta[4] = 74 <br><br>
 * se recebe como argumento, por exemplo, "21,23,25,80", retorna um array da seguinte forma:<br>
 * $porta[0] = 21 <br>
 * $porta[1] = 23 <br>
 * $porta[2] = 25 <br>
 * $porta[3] = 80 <br>
 */
function prepara_portas($porta)
{
    if (strpos($porta,"-") && strpos($porta,","))
    {
        return("ERRO");
    }

    if (strpos($porta,"-"))
    {    
        $porta = trim($porta);
        $porta = str_replace(" ","",$porta);
        $porta = explode("-",$porta);
    
        $portaTam = sizeof($porta);
    
        if ($portaTam != 2){return(0);}
    
        $portas['ini'] = $porta[0];
        $portas['fim'] = $porta[1]+1;
    
        $cont = 0;

        while ($portas['ini'] < $portas['fim'])
        {
            $poVitima[$cont] = $portas['ini'];
            $portas['ini']++;
            //echo $portas['ini']."<br>";
            $cont++;
        }
        if (sizeof($poVitima) > _MAX_PORTAS_)
        {
            return ("ERRO");
        }
        return ($poVitima);
    }
    if (strpos($porta,","))
    {    
        $porta = trim($porta);
        $porta = str_replace(" ","",$porta);
        $portas = explode(",",$porta);
        unset($porta);
        
        $Qportas = sizeof($portas);
        $priPorta = $portas[0];
        $ultPorta = $portas[$Qportas-1];

        for($cont = 0; $cont < $Qportas; $cont++)
        {
            $porta[$cont] = $portas[$cont];
        }
        if (sizeof($porta) > _MAX_PORTAS_)
        {
            return ("ERRO");
        }
        return($porta);
    }
    return($porta);
}

/***
 * FUNCAO BONECO
 *
 * Exibe aquele lindo bonequinho que ajuda...
 */
function boneco_ajuda($msg = _MSG_ABOUT_)
{
    if ($msg != _MSG_ABOUT_)
    {
        $msg = exibe_ajuda($msg);
    }
    echo "<img align=right width=50 src='img/personal.png'".
         " onclick=\"javascript:alert('$msg',3);\">";
    return(0);
}

/***
 * FUNCAO IS SLAVE
 *
 * Pergunta se o slave e' mesmo um slave
 * retorna 1 se for
 */
function is_slave($slave_addr)
{
    $slave_ass = _SLAVE_ASS_;
    $link = fopen ($slave_addr."?is_slave=1","r");
    $assin = fread($link,strlen($slave_ass));
    fclose($link);
    if ($assin != $slave_ass){return(0);}
    return(1);
}

/**
 * FUNCAO IS MASTER
 *
 * Verifica se o master e' mesmo master
 * retorna 1 SE FOR.
 */
function is_master($master_addr)
{
    $master_ass = _MASTER_ASS_;
    $link = fopen ($master_addr."?is_master=1","r");
    $assin = fread($link,strlen($master_ass));
    fclose($link);
    if ($assin != $master_ass){return(0);}
    return(1);
}    
    
/**
 * FUCAO GETMICROTIME
 *
 * getmicrotime() padrao unix, utilizado para contagem de segundos que leva
 * o scan
 */
function getmicrotime()
{
 list($usec, $sec) = explode(" ",microtime());
 return ((float)$usec + (float)$sec);
}

/**
 * FUNCAO HELP
 *
 * Exibe ajuda para cada tela.
 */
function exibe_ajuda ($tela)
{
    switch ($tela)
    {
        case (1):
        {
            return (msg_ajuda_principal);
            break;
        }
        case (2):
        {
            return (msg_ajuda_end_slave);
            break;
        }
        case (3):
        {
            return (msg_ajuda_confirma);
            break;
        }
        case (4):
        {
            return (msg_ajuda_final);
            break;
        }
        case ("ERRO"):
        {
            return (msg_ajuda_erro);
            break;
        }

    }                  
}

/**
 * FUNCAO INICIO DE PAGINA
 *
 * Cria o inicio da pagina
 */
function inicioPagina()
{
echo '
<html>
<title>'._TITULO_.'</title>
<body>
<link REL="StyleSheet" HREF="img/main.css" TYPE="text/css">
<center>
<table width="755" height="470" cellspacing="0">
    <tr>
        <td valign="top">
        
        <table width="750" cellspacing="0">
            <tr>
                <td width="100"></td>
                <td></td>
                <td width="650" class=ttitulo>
                    <font class=titulo><b><div align="right">'.
                    _TITULO_
                    .'</div></b></font>
                </td>
                <td class=tdireita>&nbsp;</td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td class=tprincipal><br></td>
                <td class=tdireita>&nbsp;</td>
            </tr>
            
            <tr>
                <td width="100" class=tlogo>
                    <center>
                    <img src="img/logo.jpg">
                    </center>
                </td>
                <td></td>
                <td width="650" class=tprincipal valign="top">';
}                

/**
 * FUNCAO FIM DE PAGINA
 *
 * Cria o final da pagina
 */
function finalPagina()
{
echo '
                    </center>
                </td>
                
                <td width="650" class=tprincipal>
                <td class=tdireita>&nbsp;</td>
                </td>
            </tr>
            
            <tr>
                <td colspan="3" class=trodape>
                    <font class=rodape><b><div align="right">'.
                    _RODAPE_
                    .'</div></b></font>
                </td>
                <td class=tdireita>&nbsp;</td>
            </tr>
            
            
        </table>
        
        
        </td>
</tr>

</table>
';
}

?>
