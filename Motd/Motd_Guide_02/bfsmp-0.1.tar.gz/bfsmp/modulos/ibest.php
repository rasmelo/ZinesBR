<?php
//                                                      ________
//                                                     | BFSMP |
// +------------------------------------------------------------+
// + Modulo Webmail Ibest - by tDs - tds@motdlabs.org           +
// +------------------------------------------------------------+
// + file: modulos/ibest.php                                    +
// +------------------------------------------------------------+
// + Modulo para verificacao de usuario e senha do webmail do   +
// + ibest.                                                     +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+

define ( "_CAMPO_USUARIO_" , "user_name" );
/* campo referente ao usuario no formulario */

define ( "_CAMPO_SENHA_" , "password" );
/* campo referente a senha no formulario */

define ("_site_","http://webmail.ibestvip.com.br/cgi-w2/entrada.fcgi?hostname=ibest.com.br&ok=Entrar&");
/* path completo para o local onde ocorre a autenticacao, incluindo uma "?"
   no final. se for necessario setar mais variaveis, sete-as apos a "?" */

?>
