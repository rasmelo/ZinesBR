<?php
//                                                      ________
//                                                     | BFSMP |
// +------------------------------------------------------------+
// + Modulo yahoo  - by tDs - tds@motdlabs.org                  +
// +------------------------------------------------------------+
// + file: modulos/yahoo.php                                    +
// +------------------------------------------------------------+
// + Modulo para entrar nos servicos do yahoo. Logando em um,   +
// + acessa todos (mail, grupos, porta-arquivos).               +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+

define ( "_CAMPO_USUARIO_" , "login" );
/* campo referente ao usuario no formulario */

define ( "_CAMPO_SENHA_" , "passwd" );
/* campo referente a senha no formulario */

define ( "_site_" , "http://login.yahoo.com/config/login?.tries=1&.v=0&.done=http://br.yahoo.com&ok=sLogin&" );
/* path completo para o local onde ocorre a autenticacao, incluindo uma "?"
   no final. se for necessario setar mais variaveis, sete-as apos a "?" */

?>
