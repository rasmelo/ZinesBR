<?php
//                                                      ________
//                                                     | BFSMP |
// +------------------------------------------------------------+
// + Modulo exemplo  - by tDs - tds@motdlabs.org                +
// +------------------------------------------------------------+
// + file: modulos/exemplo.php                                  +
// +------------------------------------------------------------+
// + Modulo de exemplo, utilizado para criacao de outros        +
// + modulos                                                    +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+

define ( "_CAMPO_USUARIO_" , "input_usuario" );
/* campo referente ao usuario no formulario */

define ( "_CAMPO_SENHA_" , "input_senha" );
/* campo referente a senha no formulario */

define ( "_site_" , "site" );
/* path completo para o local onde ocorre a autenticacao, incluindo uma "?"
   no final. se for necessario setar mais variaveis, sete-as apos a "?" */

?>
