<?
//                                                      ________
//                                                     | BFSMP |
// +------------------------------------------------------------+
// + Arquivo de funcoes  - by tDs - tds@motdlabs.org            +
// +------------------------------------------------------------+
// + file: inc/funcoes.inc.php                                  +
// +------------------------------------------------------------+
// + Diversas funcoes utilizadas. Se escrever uma nova funcao,  +
// + coloque-a aqui.                                            +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+

/***
 * criar arquivo temporario
 */
function temp_arq($f_nome,$f_cont)
{
  $fd  = fopen($f_nome,"w+");
  fwrite($fd,$f_cont);
  fclose($fd);
  return;
}


/***
 * retorna horario
 */ 
function ret_time()
{
    $t = date("H:i");
    return $t;
}


/***
 * funcao microtime
 */
function getmicrotime()
{
    list($usec, $sec) = explode(" ",microtime());
    return ((float)$usec + (float)$sec);
}


/***
 * retorna usuarios do arquivo usuarios.txt
 */
function ret_usuario()
{
    $flag = 0;
    $arquivo = "usuarios.txt";
    if ( !file_exists( $arquivo ) )
    {
        echo "
            <script>
            alert ('O arquivo com os usuarios validos n�o existe.');
            </script>
            " ;
        return("ERRO");
    }

    if( ! $ret = fopen( $arquivo,"r") )
    {
        echo "
            <script>
            alert ('Ocorreu um erro ao acessar o arquivo com usuarios".
            " validos.');
            </script>
            " ;
        return("ERRO");
    }

    $cont = 0;
    while ( ! feof ($ret))
    {
        $linha[$cont] = fgets ($ret,4096);
        $linha[$cont] = str_replace("\n","",$linha[$cont]);
        $linha[$cont] = str_replace("\r","",$linha[$cont]);
        $cont++;
    }

    $ret = fclose( $ret );
    return $linha;
}


/***
 * retorna senha do arquivo dic.txt
 */
function ret_senha()
{
    $flag = 0;
    $arquivo = "dic.txt";
    if ( !file_exists( $arquivo ) )
    {
        echo "
            <script>
            alert ('O arquivo com as senhas (dic) n�o existe.');
            </script>
            " ;
        return("ERRO");
    }

    if( ! $ret = fopen( $arquivo,"r") )
    {
        echo "
            <script>
            alert ('Ocorreu um erro ao acessar o arquivo com as".
            " senhas (dic).');
            </script>
           " ;
        return("ERRO");
    }


    $cont = 0;
    while ( ! feof ($ret))
    {
        $linha[$cont] = fgets ($ret,4096);
        $linha[$cont] = str_replace("\n","",$linha[$cont]);
        $linha[$cont] = str_replace("\r","",$linha[$cont]);
        $cont++;
    }

    $ret = fclose( $ret );
    return $linha;

}

/***
 * limpa codigo fonte da pagina
 */
function limparFonte ($fonte)
{
    $fonte = strip_tags($fonte);
    /* retira as tags html do source da pagina */

    $fonte = str_replace(" ","",$fonte);
    $fonte = str_replace("&nbsp;","",$fonte);
    /* retira os espacos */

    $fonte = str_replace("\n","",$fonte);
    $fonte = str_replace("\r","",$fonte);
    $fonte = str_replace("\t","",$fonte);
    /* retira os caracteres de new line, tab e return*/
    
    return($fonte);
}


/***
 * exibe menu
 */
function menu()
{
    echo "
            &ne;<a href=index.php?opcao=>Inicio</a>&ne;&nbsp;
            &ne;<a href=index.php?opcao=iniciar>Manda ver!</a>&ne;&nbsp;";
    if(_DEBUG_)
    {
        echo "&ne;<a href=index.php?opcao=iniciar_debug>Manda ver c/ Debug!
                </a>&ne;&nbsp;
            &ne;<a href=index.php?opcao=debug>Debug only!</a>&ne;&nbsp;";
    }
   
    return(0);

}


/***
 * verifica se a opcao selecionada e' valida
 */
function isOpcao($op)
{
    if ($op == "iniciar" || $op == "iniciar_debug" || $op == "debug")
    {
        return(1);
    }
    return(0);
}


/***
 * define opcoes do script conforme opcao do menu
 */
function definirOpcao($opcao)
{
    /* se foi selecionado no menu "Manda ver c/ Debug!"... */
    if ($opcao == "iniciar_debug")
    {
        define ( "_inicio_" , "ok" );
        define ( "_debugging_online_" , "testando..." );
        return(0);
    }

    /* se foi selecionado no menu "Debug only"... */
    if ($opcao == "debug")
    {
        define ( "_debugging_" , "testando..." );
        return(0);
    }

    /* se foi selecionado no menu "Manda ver"... */
    if ($opcao == "iniciar")
    {
        define ( "_inicio_" , "ok" );
        return(0);
    }
}


/***
 * funcao echo com \n no final
 */
function mostra($a)
{
    echo "$a\n";
}


/***
 * exibe rodape da pagina
 */
function rodape()
{
    echo "&nbsp;
        <table width=601 bgcolor=#000000>
            <tr>
                <td>
                    <table width=600 bgcolor=#ffffff>
                        <tr>
                            <td><center>";
                                echo _RODAPE_."
                                </center>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>";
    return(0);
}

?>
