<?
//                                                      ________
//                                                     | BFSMP |
// +------------------------------------------------------------+
// + Arquivo de inclusao de modulos - by tDs - tds@motdlabs.org +
// +------------------------------------------------------------+
// + file: inc/modulos.inc.php                                  +
// +------------------------------------------------------------+
// + configuracoes diversas para execucao do script estao aqui. +
// + Se for necessario um novo define(), coloque-o aqui.        +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+

if (!file_exists("modulos/"._MODULO_.".php"))
{
    echo "O modulo selecionado nao existe.<br> Verifique seu arquivo".
         "'<u>inc/cfg.inc.php</u>'.";
         die();
}
include ("modulos/"._MODULO_.".php");
?>
