<?
//                                                      ________
//                                                     | BFSMP |
// +------------------------------------------------------------+
// + Arquivo de configuracoes  - by tDs - tds@motdlabs.org      +
// +------------------------------------------------------------+
// + file: inc/cfg.inc.php                                      +
// +------------------------------------------------------------+
// + configuracoes diversas para execucao do script estao aqui. +
// + Se for necessario um novo define(), coloque-o aqui.        +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+

define("_TITULO_","BFSMP - *Versao Beta* - by tDs");
define("_RODAPE_","BFSMP - *Versao Beta* - by <a href=".
       "mailto:tds@motdlabs.org>tDs</a> | <a href=http://motdlabs.org>".
       "motdlabs</a>");


define("_us_valido_","USUARIO");
define("_se_valido_","SENHA");
/* voce precisa especificar um usuario e senha valido */

define("_us_invalido_","USUARIO");
define("_se_invalido_","SENHA");
/* voce precisa especificar um usuario e senha invalido */

set_time_limit (0);
/* coloque um tempo em segundos aqui,que sera o tempo
    maximo de o script vai funcionar. Coloque em 0 para 
    para que execute ate o final. */

define("_OFFSET_","-5.1");
/* esta e' a variavel mais importante, veja em help.htm*/

define("_DEBUG_","0");
/* exibe as opcoes de debug no menu */

define("_MODULO_","ibest");
/* modulo a ser utilizado */

define("_MOSTRAR_ERROS_",0);
/* mostrar mensagens de erro, util no desenvolvimento de
   modulos e para debugging. */

?>
