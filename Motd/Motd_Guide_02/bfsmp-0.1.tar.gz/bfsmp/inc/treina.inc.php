<?php    
//                                                      ________
//                                                     | BFSMP |
// +------------------------------------------------------------+
// + Arquivo de treinamento  - by tDs - tds@motdlabs.org        +
// +------------------------------------------------------------+
// + file: inc/treina.inc.php                                   +
// +------------------------------------------------------------+
// + funcoes de treinamento do script, futuras funcoes para     +
// + verificacao de digitos em imagens vao ficar  aqui.         +
// +                                                            +
// + Use por conta e risco                                      +
// + Nao me responsabilizo por nada que venha a ser feito       +
// + decorrente do uso deste script.                            +
// +                                                            +
// + Use para fins educacionais :)                              +
// +------------------------------------------------------------+

/*** 
 * primeiro treinamento, com usuario e senha invalido
 */
function treinaErro($usuario_invalido,$senha_invalida)
{
    $link_ERRO = _site_._CAMPO_USUARIO_."=$usuario_invalido&"._CAMPO_SENHA_.
                 "=$senha_invalida";
    /* cria o link com o site o usuario e a senha invalidos */

    $alvo_ERRO = fopen ("$link_ERRO","r");
    /* abre o link */
    
    $try_ERRO = fread($alvo_ERRO,100000);
    /* le o link */
   
    $try_ERRO = limparFonte ($try_ERRO);
    /* limpa o fonte da pagina */
    
    $ret[0] = $link_ERRO;
    $ret[1] = $try_ERRO;
    return($ret);
}
    
/*** 
 * segundo treinamento, com usuario e senha valido
 */
function treinaOK($usuario_valido,$senha_valida)    
{
        
    $link_OK = _site_._CAMPO_USUARIO_."=$usuario_valido&"._CAMPO_SENHA_.
               "=$senha_valida";
    /* cria o link com o site o usuario e a senha validos */

    $alvo_OK = fopen ($link_OK,"r");
    /* abre o link */
    
    $try_OK = fread($alvo_OK,100000);
    /* le o link */

    $try_OK = limparFonte ($try_OK);
    /* limpa o fonte da pagina */

    $ret[0] = $link_OK;
    $ret[1] = $try_OK;
    return($ret);
    
 }   
?>
